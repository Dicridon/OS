A 65
B 66
C 67  page fault
D 68
E 69
F 70
G 71  general
H 72  general
I 73
J 74
K 75  handle tlb c
L 76
M 77
N 78
O 79  odd page
P 80 
Q 81 
R 82  return form exception
S 83
T 84  leave tlb
U 85
V 86  even page
W 87
X 88
Y 89
Z 90
